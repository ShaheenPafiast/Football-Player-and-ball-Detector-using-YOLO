# Football Players Detection > 2025-08-08 11:44am
https://universe.roboflow.com/shoplifting-j87tw/football-players-detection-kbnc2-wjb5g

Provided by a Roboflow user
License: CC BY 4.0

